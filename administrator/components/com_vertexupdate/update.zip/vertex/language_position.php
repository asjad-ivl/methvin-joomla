<?php if ($s5_pos_language == "published") { ?>
	<div id="s5_pos_language">
		<?php s5_module_call('language','notitle'); ?>
	</div>
<?php } ?>